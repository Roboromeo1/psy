using System;
using SplashKitSDK;
    public class WithdrawTransaction
    {
        private Account _account;
        private decimal _amount;
        private bool _executed = false;
        private bool _success = false;
        private bool _reversed = false;

        public bool Success
        {
            get
            {  
                return _success;
            }
        }

        public bool Executed
        {
            get
            {
                return _executed;
            }
        }

        public bool Reversed
        {
            get
            {
                return _reversed;
            }
        }
        public WithdrawTransaction(Account account, decimal amount)
        {
            _account = account;
            _amount = amount;
        }
        public void Execute()
        {
            if ( _executed )
            {
                throw new Exception("Cannot execute this transaction as it has already executed");
            }
            _executed = true;
            _success = _account.withdraw(_amount);
        }

        public void Rollback()
        {
            if (_reversed == true)
            {
                throw new Exception("The Transaction has been Reversed.");
            }
            else if (_executed == false)
            {
                throw new Exception("The Transaction has not been Executed.");
            }
            _reversed = true;
            _account.Deposit(_amount);

        }
        public void Print()
        {
            if  (_success == true)
            {
                Console.WriteLine("Transaction has been successful");
                Console.WriteLine("The total amount withdrawn is {0}", _amount);
            }
            if (_reversed == true)
            {
                Console.WriteLine("The transaction was reversed");
            }
            if (_success == false)
            {
                Console.WriteLine("The withdraw was not successful");
            }
            
        }
    }
   
