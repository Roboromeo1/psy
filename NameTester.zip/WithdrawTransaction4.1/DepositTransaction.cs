using System;
using SplashKitSDK;

public class DepositTransaction
{
    private Account _account;
    private decimal _amount;
    private bool _executed = false;
    private bool _success = false;
    private bool _reversed = false;

    public bool Executed
    {
        get
        {
            return _executed;
        }
    }

    public bool Success
    {
        get
        {
            return _success;
        }
    }

    public bool Reversed
    {
        get
        {
            return _reversed;
        }
    }

    public DepositTransaction(Account account, decimal amount)
    {
        _account = account;
        _amount = amount;
    }

    public void Execute()
    {
        if ( _executed)
        {
            throw new Exception("Cannot execute this transaction as it has already executed");
        }

        _executed = true;
        _success = _account.Deposit(_amount);
    }

    public void Rollback()
    {
        if (_reversed == true)
        {
            throw new Exception("Transaction has already been Reversed");
        }
        else if (_executed == false)
        {
            throw new Exception("Transaction has not been Executed");
        }
        _reversed = true;
        _account.Deposit(_amount);
    }
    public void print()
    {
        if (_success == true)
        {
            Console.WriteLine("The Deposit Transaction has been successful");
            Console.WriteLine("The total amount deposited is {0}", _amount);
        }
        if (_success == false)
        {
            Console.WriteLine("The transaction was declined");
        }
        if (_reversed == true)
        {
            Console.WriteLine("The transaction has been Reversed");
        }
    }
}