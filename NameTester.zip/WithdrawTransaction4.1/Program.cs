using System;
using SplashKitSDK;

namespace Project1
{
enum MenuOption
{
    Withdraw,
    Deposit,
    Print,
    Transfer,
    Quit
}
public class Program
{
    
public static void DoWithdraw(Account account)
{
    decimal amountToWithdraw = 0;
    do
    {
        Console.WriteLine("How much would you like to withdraw: ");
        try 
        {
            amountToWithdraw = Convert.ToDecimal(Console.ReadLine());
            break;
        }
        catch
        {
            Console.WriteLine("Invalid Input");
        }
    } 
    while (true);
    WithdrawTransaction Withdraw = new WithdrawTransaction(account, amountToWithdraw);
    Withdraw.Execute();
    Withdraw.Print();
}
public static void DoDeposit(Account account)
{
    decimal amountToDeposit = 0;
    do
    {
        Console.WriteLine("How much do you want to deposit: ");
        try
        {
            amountToDeposit = Convert.ToDecimal(Console.ReadLine());
            break;
        }
        catch
        {
            Console.WriteLine("Invalid Input");
        }
    } while(true);
    DepositTransaction deposit = new DepositTransaction(account, amountToDeposit);
    deposit.Execute();
    deposit.print();
}
private static MenuOption ReadUserOption()
    {
        int option = 0;
        Console.WriteLine("*****************************");
        Console.WriteLine("Choose in the following options");
        Console.WriteLine(" 1. Withdraw");
        Console.WriteLine(" 2. Deposit");
        Console.WriteLine(" 3. Print");
        Console.WriteLine(" 4. Transfer");
        Console.WriteLine(" 5. Quit");
        Console.WriteLine("*****************************");
    do
    {
        try
        {
            option = Convert.ToInt32(Console.ReadLine());
        }
        catch
        {
            Console.WriteLine("Invalid Input");
            option = -1;
        }
    } while (option < 1 || option > 4);

    return (MenuOption)(option - 1);
}
public static void TransferTransaction(Account account, Account myAccount)
{
    decimal amount = 0;
    do
    {
        Console.WriteLine("Enter the value: ");
        try
        {
            amount = Convert.ToDecimal(Console.ReadLine());
            break;
        }
        catch
        {
            Console.WriteLine("Invalid Input");
        }
    }while(true);
    TransferTransaction TransferTransaction = new TransferTransaction(myAccount, account, amount);
    TransferTransaction.Execute();
    TransferTransaction.print();
}
public static void DoPrint(Account account, Account myAccount)
{
    account.print();
    myAccount.print();
}
    public static void Main()
    {
        MenuOption userSelection;
        Account account = new Account("Satwik", 200000);
        Account myAccount = new Account("Krish", 2000000);
        do
        {
            userSelection = ReadUserOption();
            switch (userSelection)
            {
                case MenuOption.Withdraw:
                Console.WriteLine("Withdraw");
                DoWithdraw(account);
                break;

                case MenuOption.Deposit:
                Console.WriteLine("Deposit");
                DoDeposit(account);
                break;

                case MenuOption.Print:
                Console.WriteLine("Print the Account Transactions");
                DoPrint(account, myAccount);
                break;

                case MenuOption.Transfer:
                Console.WriteLine("Make the Transfer");
                TransferTransaction(account, myAccount);
                break;
        
                case MenuOption.Quit:
                Console.WriteLine("Thank you for banking with us.");
                break;
            }
        } while (userSelection != MenuOption.Quit);
    }
}
}