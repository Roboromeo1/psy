using System;
using SplashKitSDK;

public class TransferTransaction
{

    private Account _toAccount;
    private Account _fromAccount;
    private decimal _amount;
    private DepositTransaction _theDeposit;
    private WithdrawTransaction _theWithdraw;
    private bool _executed = false;
    private bool _success = false;
    private bool _reversed = false;

    public bool Executed
    {
        get
        {
            return _executed;
        }
    }

    public bool Success
    {
        get
        {
            return _success;
        }
    }

    public bool Reversed
    {
        get
        {
            return _reversed;
        }
    }
    public TransferTransaction(Account fromAccount, Account toAccount, decimal amount)
    {
        _toAccount = toAccount;
        _fromAccount = fromAccount;
        _amount = amount;
        _theDeposit = new DepositTransaction(_toAccount, _amount);
        _theWithdraw = new WithdrawTransaction(fromAccount, _amount);
    }

    public void Execute()
    {
        if ( _executed)
        {
            throw new Exception("Cannot execute this transaction as it has already executed");
        }
        _executed = true;
        _theWithdraw.Execute();

        if (_theWithdraw.Success)
        {
            _theDeposit.Execute();
        }
        else 
        {
            _theWithdraw.Rollback();
        }
        
        if (!_theDeposit.Success)
        {
            _theDeposit.Rollback();
        }
        else if (_theDeposit.Success == true && _theWithdraw.Success == true)
        {
            _success = true;
        }
    }

    public void Rollback()
    {
        if (_reversed == true)
        {
            throw new Exception("Transaction has already been Reversed");
        }
        else if (_executed == false)
        {
            throw new Exception("Transaction has not been Executed");
        }
        if (_theDeposit.Success == true)
        {
            _theDeposit.Rollback();
        }
        if(_theWithdraw.Success == true)
        {
            _theWithdraw.Rollback();
        }
    }
    public void print()
    {
        Console.WriteLine("From {0} To {1} The Amount Transferred is {2}", _fromAccount.Name, _toAccount, _amount);
        _fromAccount.print();
        _toAccount.print();
    }
}