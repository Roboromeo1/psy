using System;
using SplashKitSDK;

public class Program
{
    public static void Main()
    {

    }
}
