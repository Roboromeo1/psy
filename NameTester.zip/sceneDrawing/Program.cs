using System;
using SplashKitSDK;

public class Program
{
    public static void Main()
    {
        Window firstWindow = new Window("Scene Drawing by Satwik", 800, 600);

        Bitmap H1 = new Bitmap("H1", "H1.png");
        Bitmap H2 = new Bitmap("H2", "H2.png");
        Bitmap H3 = new Bitmap("H3", "H3.png");
        Bitmap H4 = new Bitmap("H4", "H4.png");

        SoundEffect humptydumpty = new SoundEffect("humptydumpty", "humptydumpty.mp3");
        humptydumpty.Play();
        
        firstWindow.DrawBitmap(H1, 50, 50);
        firstWindow.Refresh(60);
        SplashKit.Delay(13000);

        firstWindow.Clear(Color.White);

        firstWindow.DrawBitmap(H2, 50, 50);
        firstWindow.Refresh(60);
        SplashKit.Delay(3000);

        firstWindow.Clear(Color.White);

        firstWindow.DrawBitmap(H3, 50, 50);
        firstWindow.Refresh(60);
        SplashKit.Delay(3000);

        firstWindow.Clear(Color.White);

        firstWindow.DrawBitmap(H4, 50, 50);
        firstWindow.Refresh(60);
        SplashKit.Delay(7000);

        firstWindow.Clear(Color.White);

        firstWindow.DrawBitmap(H1, 50, 50);
        firstWindow.Refresh(60);
        SplashKit.Delay(6000);

        firstWindow.Clear(Color.White);

        firstWindow.DrawBitmap(H2, 50, 50);
        firstWindow.Refresh(60);
        SplashKit.Delay(4000);

        firstWindow.Clear(Color.White);

        firstWindow.DrawBitmap(H3, 50, 50);
        firstWindow.Refresh(60);
        SplashKit.Delay(3000);

        firstWindow.Clear(Color.White);

        firstWindow.DrawBitmap(H4, 50, 50);
        firstWindow.Refresh(60);
        SplashKit.Delay(7000);
       
        SplashKit.Delay(25000);
        
    }
}
