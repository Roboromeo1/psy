using System;

public class Account
{
    private decimal _balance;
    private string _name;
public Account(string name, decimal startingBalance)
{
    _name = name;
    _balance = startingBalance;
}
public void Deposit(decimal amountToAdd)
{
    _balance = _balance + amountToAdd;
}
public void withdraw(decimal amountToDraw)
{
    _balance = _balance - amountToDraw;
}
public string Name
{
    get{return _name;}
}
public void print()
{
    Console.WriteLine("Hi " + Name + " The Remaining amount in your account is : " + _balance);
}
}