using System;
using SplashKitSDK;
public class Program
{
    public static void Main()
    {
        Account account = new Account("Satwik", 200000);

        account.print();
        account.Deposit(100);
        account.print();
        account.withdraw(50);
        account.print();

        Account SecondAccount = new Account("Krishna", 5000000);

        SecondAccount.print();
        SecondAccount.Deposit(5);
        SecondAccount.print();
        SecondAccount.withdraw(7);
        SecondAccount.print();
        SecondAccount.Deposit(50);
        SecondAccount.print();

    }
}