using System;
using SplashKitSDK;

public class Program
{
    public static int ReadInteger(string prompt)
    {
        Console.Write(prompt);
        while (true)
        {
            try
            {
                return Int32.Parse(Console.ReadLine());
            }
            catch
            {
                Console.WriteLine("Please enter a valid integer");
            }
        }
    }
    public static double ReadDouble(string prompt)
    {
        Console.Write(prompt);
        while (true)
        {
            try
            {
                return double.Parse(Console.ReadLine());
            }
            catch
            {
                Console.WriteLine("Please Enter the value");
            }
        }
    }
    public static void Main()
    {
        int numberofValues = ReadInteger("Enter number of values: ");
        double[] values = new double[numberofValues];

        for (int i = 0; i < numberofValues; i++)
        {
            values[i] = ReadDouble($"Enter the {i + 1}st value: ");
        }
        double sum = 0;
        foreach (var value in values)
        {
            Console.WriteLine(value);
            sum += value;
        }
        Console.WriteLine("The sum of the values given is " + sum);
    }
}
