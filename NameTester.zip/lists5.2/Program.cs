using System;
using System.Collections.Generic;
using SplashKitSDK;

public class Program
{
    public enum UserOption
    {
        NewValue,
        Sum,
        Print,
        Quit
    }
    private static List<double> _values = new List<double>();

    public static int ReadInteger(string prompt)
    {
        Console.Write(prompt);
        while (true)
        {
            try
            {
                return Int32.Parse(Console.ReadLine());
            }
            catch
            {
                Console.WriteLine("Please Enter a valid integer");
            }
        }
    }
    public static double ReadDouble(string prompt)
    {
        Console.Write(prompt);
        while (true)
        {
            try
            {
                return double.Parse(Console.ReadLine());
            }
            catch
            {
                Console.WriteLine("Enter Double Value");
            }
        }
    }

    public static UserOption ReadUserOption()
    {
        int option = 3;

        Console.WriteLine("Enter 0 to add a value");
        Console.WriteLine("Enter 1 to add a sum all values");
        Console.WriteLine("Enter 2 to print a sum all values");
        Console.WriteLine("Enter 3 to quit");
        Console.Write("Enter A Number: ");
        Int32.TryParse(Console.ReadLine(), out option);

        return (UserOption)option;
    }

    public static void AddValueToList()
    {
        var numberToList = ReadDouble("Which number would you like to add to the list? : ");
        _values.Add(numberToList);
    }

    public static void Sum()
    {
        double sumOfNumbers = 0;
        foreach( var item in _values)
        {
            sumOfNumbers += item;
        }
        Console.WriteLine("The total sum of all values is "+ sumOfNumbers);
    }

    public static void Print()
    {
        foreach ( var value in _values)
        {
            Console.WriteLine(value.ToString());
        }
    }
    
    public static void Main()
    {
        UserOption userSelection;

        do
        {
            userSelection = ReadUserOption();
            switch (userSelection)
            {
                case UserOption.NewValue:
                AddValueToList();
                break;

                case UserOption.Sum:
                Sum();
                break;

                case UserOption.Print:
                Print();
                break;

                case UserOption.Quit:
                break;
            }

        }while (userSelection != UserOption.Quit);
    }
}
