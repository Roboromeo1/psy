using System;

namespace NameTester
{

    public enum Menuoption
    {
        TestName,
        GuessThatNumber,
        Quit
    }

    class Program
    {
        private static Menuoption ReadUserOption()
        {
            int  option;
            Console.WriteLine("*********************");
            Console.WriteLine("1. TestName ");
            Console.WriteLine("2. Guess That Number ");
            Console.WriteLine("3. Quit ");
            Console.WriteLine("**********************");

            do
            {
                Console.Write("Choose an option [1-3]:");
                try
                {
                    option = Convert.ToInt32(Console.ReadLine());
                }
                catch
                {
                    Console.WriteLine("Invalid Input");
                    option = -1;
                }
                
            } while (option < 1 || option > 3);

            return (Menuoption)(option - 1);
        }
        public static void TestName()
        {
            string name;
            Console.Write("Please Enter Your Full name: ");
            name = Console.ReadLine();

            if (name.ToLower() == "soudeh kasiri bidhendi")
            {
                Console.WriteLine("Welcome Mam");
            }
            else if (name.ToLower() == "andrew cain")
            {
                Console.WriteLine("Welcome Professor");
            }
            else if (name.ToLower() == "satwik")
            {
                Console.WriteLine("Welcome Student");
            }
            else
            {
                Console.WriteLine("Welcome to my Program " + name);
            }
        }
    public static void RunGuessThatNumber()
    {
        int target;
        int guess;
        int lowestGuess, highestGuess;

        guess = 0;
        highestGuess = 100;
        lowestGuess = 1;

        target = new Random().Next(100) + 1;
        

        while (target != guess)
        {
            guess = ReadGuess(highestGuess, lowestGuess);
            if (guess > target)
            {
                Console.WriteLine("The number you have entered is less than the Target");
                highestGuess = guess;
            }
            else if ( guess < target)
            {
                Console.WriteLine("The number you have entered is greater than the target");
                lowestGuess = guess;
            }
            else
            {
                Console.WriteLine("You have guessed the number ");
            }
        }
        
    }
    private static int ReadGuess(int max, int min)
    {
        int number;
        do
        {
            Console.WriteLine(" Enter your guess between {1} and {0}", max, min);
            try
            {
                number = Convert.ToInt32(Console.ReadLine());
            }
            catch
            {
                Console.WriteLine("Invalid Input");
                number = -1;
            }

        }while (number > max || number < min);

        return number;
    }
        static void Main()
        {
            Menuoption userSelection;

            do
            {
                userSelection = ReadUserOption();
                switch(userSelection)
                {
                case Menuoption.TestName:
                    TestName();
                    break;
                case Menuoption.GuessThatNumber:
                    RunGuessThatNumber();
                    break;
                case Menuoption.Quit:
                    Console.WriteLine("I Quit.");
                    break;
                }
            }while (userSelection != Menuoption.Quit);

        }
    }
}