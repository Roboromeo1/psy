using System;
using SplashKitSDK;

public class Program
{
    public static void Main()
    {
        string name;
        string inputText;
        int heightInCM;
        string text;

        Console.Write("Enter your name: ");
        name = Console.ReadLine();
        Console.WriteLine("Hello " + name);

        Console.Write("How Tall are you (in CM): ");
        inputText = Console.ReadLine();
        
        heightInCM = Convert.ToInt32(inputText);

        double heightInMeters = heightInCM / 100.0;

        Console.Write("Enter your weight: ");
        text = Console.ReadLine();

        double weight = Convert.ToDouble(text);

        double BMI = weight / (heightInMeters * heightInMeters);
     
        Console.WriteLine("Hello " + name);
        Console.WriteLine("Your height is " + heightInMeters + " Meters");
        Console.WriteLine("Your weight is " + weight + " Kilograms");
        Console.WriteLine("Your BMI is " + BMI);
        Console.ReadLine();

    }
}
