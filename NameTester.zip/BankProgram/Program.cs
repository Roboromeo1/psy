using System;
using SplashKitSDK;

namespace Project1
{
enum MenuOption
{
    Withdraw,
    Deposit,
    Print,
    Quit
}
public class Program
{
    private static MenuOption ReadUserOption()
    {
        int option = 0;
        Console.WriteLine("*****************************");
        Console.WriteLine("Choose in the following options");
        Console.WriteLine(" 1. Withdraw");
        Console.WriteLine(" 2. Deposit");
        Console.WriteLine(" 3. Print");
        Console.WriteLine(" 4. Quit");
        Console.WriteLine("*****************************");
    do
    {
        try
        {
            option = Convert.ToInt32(Console.ReadLine());
        }
        catch
        {
            Console.WriteLine("Invalid Input");
            option = -1;
        }
    } while (option < 1 || option > 4);

    return (MenuOption)(option - 1);
}
public static void DoWithdraw(Account account)
{
    decimal amountToWithdraw = 0;
    do
    {
        Console.WriteLine("How much would you like to withdraw: ");
        try 
        {
            amountToWithdraw = Convert.ToDecimal(Console.ReadLine());
            break;
        }
        catch
        {
            Console.WriteLine("Invalid Input");
        }
    } while (true);
    bool result = account.withdraw(amountToWithdraw);
    if (result == true)
    {
        Console.WriteLine("Withdraw is Successful");
    }
    else
    {
        Console.WriteLine("Withdraw is not successful");
    }
}
public static void DoDeposit(Account account)
{
    decimal amountToDeposit = 0;
    do
    {
        Console.WriteLine("How much do you want to deposit: ");
        try
        {
            amountToDeposit = Convert.ToDecimal(Console.ReadLine());
            break;
        }
        catch
        {
            Console.WriteLine("Invalid Input");
        }
    } while(true);

    bool result = account.Deposit(amountToDeposit);
    if (result == true)
    {
        Console.WriteLine("Deposit is successful");
    }
    else
    {
        Console.WriteLine("Your Deposit was not successful");
    }
}

public static void DoPrint(Account account)
{
    account.print();

}
    public static void Main()
    {
        MenuOption userSelection;
        Account account = new Account("Satwik", 200000);
        do
        {
            userSelection = ReadUserOption();
            switch (userSelection)
            {
                
                case MenuOption.Withdraw:
                DoWithdraw(account);
                break;

                case MenuOption.Deposit:
                DoDeposit(account);
                break;


                case MenuOption.Print:
                DoPrint(account);
                break;

                case MenuOption.Quit:
                Console.WriteLine("Thank you for banking with us.");
                break;
            }
        } while (userSelection != MenuOption.Quit);
    }
}
}